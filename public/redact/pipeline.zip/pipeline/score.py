from typing import List
from pipeline.redact import Config
from pipeline.ner import EntityMapping


class RiskScorer:
    def score(self, entities: List[EntityMapping], config: Config) -> int:
        """
        Score the risk of the given entities. This method should be implemented
        by subclasses.

        :param entities: The entities to score.
        :param config: The config dict that contains admin panels.
        :raises NotImplementedError: If the subclass does not implement this
        method.
        """
        raise NotImplementedError("Subclasses must implement this method.")


class SimpleRiskScorer(RiskScorer):
    """
    A simple risk scorer that calculates the risk based on the maximum
    sensitivity of the text.
    """

    def score(self, entities: List[EntityMapping], config: Config) -> int:
        score = 0
        for entity in entities:
            entity_name: str = entity[0]
            if entity_name in config and config[entity_name][1] != "passthrough":
                score = max(score, config[entity_name][0])
        return score
