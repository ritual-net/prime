import json
from pipeline.ner import NER_DETECTORS
from pipeline.score import SimpleRiskScorer
from pipeline.redact import Redactor, Config


def detect(detector: str, prompt: str, config: Config) -> str:
    """Detects PII in prompt based on config and selected NER detector

    Args:
        detector (str): to index NER_DETECTORS
        prompt (str): from user
        config (Config): entity config

    Returns:
        Tuple[int, Dict, str, Dict]: Stringifed JSON: Risk score, Modified request, entity mapping, redaction map
    """
    entity_map = NER_DETECTORS[detector]().standardize_entities(prompt)
    risk_score = SimpleRiskScorer().score(entity_map, config)
    if len(entity_map) > 0:
        new_prompt, redact_map = Redactor().redact(prompt, entity_map, config)
    else:
        new_prompt, redact_map = prompt, {}
    return json.dumps(
        {
            "risk_score": risk_score,
            "entity_map": entity_map,
            "new_prompt": new_prompt,
            "redact_map": redact_map,
        }
    )
