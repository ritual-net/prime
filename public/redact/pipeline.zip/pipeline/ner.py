from typing import Dict, List, Tuple

# Entity mapping (type => value)
EntityMapping = Tuple[str, str]


class NERBase:
    def detect(self, text: str) -> List[EntityMapping]:
        """
        Detects named entities in the given text.

        Args:
            text (str): The text to detect entities in.

        Returns:
            entities (list): Entities in the model-specific format of
            [(Category), (entityStr)].
        """
        raise NotImplementedError("Subclass must implement abstract method")

    def standardize_entities(self, text: str) -> List[EntityMapping]:
        """
        Standardizes the detected entities in the format of a lowest
        denominator common category.

        Args:
            text (str): The text to detect entities in. Usually the full
            prompt request.

        Returns:
            entities (list): Entities in the standardized config format of
            [(Category), (entityStr)].
        """
        raise NotImplementedError("Subclass must implement abstract method")


class SpacyNER(NERBase):
    def __init__(self):
        import spacy

        # Setup
        self.nlp = spacy.load("en_core_web_sm")
        self.entity_mapping = {
            "PERSON": "Name",
            "NORP": "Group",
            "FAC": "Location",
            "ORG": "Organization",
            "GPE": "Location",
            "LOC": "Location",
            "PRODUCT": "Product",
            "EVENT": "Event",
            "WORK_OF_ART": "Work of Art",
            "LAW": "Law",
            "LANGUAGE": "Language",
            "DATE": "Date",
            "TIME": "Time",
            "PERCENT": "Percent",
            "MONEY": "Money",
            "QUANTITY": "Quantity",
            "ORDINAL": "Ordinal",
            "CARDINAL": "Cardinal",
            "ORGANIZATION": "Organization",
            "LOCATION": "Location",
            "FACILITY": "Location",
        }

    def detect(self, text: str) -> List[EntityMapping]:
        doc = self.nlp(text)
        return [(ent.text, ent.label_) for ent in doc.ents]

    def standardize_entities(self, text) -> List[EntityMapping]:
        entities = self.detect(text)
        return [(self.entity_mapping.get(ent[1], ent[1]), ent[0]) for ent in entities]


class NltkNER(NERBase):
    def __init__(self):
        import nltk

        # Install required nltk dependencies
        nltk.download("punkt")
        nltk.download("averaged_perceptron_tagger")
        nltk.download("maxent_ne_chunker")
        nltk.download("words")

        # Setup
        self.nltk = nltk
        self.nlp = self.nltk.ne_chunk
        self.entity_mapping = {
            "PERSON": "Name",
            "ORGANIZATION": "Organization",
            "LOCATION": "Location",
            "DATE": "Date",
            "TIME": "Time",
            "MONEY": "Money",
            "PERCENT": "Percent",
            "FACILITY": "Location",
            "GPE": "Location",
        }

    def detect(self, text: str) -> List[EntityMapping]:
        doc = self.nlp(self.nltk.pos_tag(self.nltk.word_tokenize(text)))
        return [
            (chunk[0][0], chunk.label()) for chunk in doc if hasattr(chunk, "label")
        ]

    def standardize_entities(self, text: str) -> List[EntityMapping]:
        entities = self.detect(text)
        return [(self.entity_mapping.get(ent[1], ent[1]), ent[0]) for ent in entities]


# Name => Detector
NER_DETECTORS: Dict[str, NERBase] = {"Spacy": SpacyNER, "Nltk": NltkNER}
