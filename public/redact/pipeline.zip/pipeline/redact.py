import uuid, re
from pipeline.ner import EntityMapping
from typing import List, Tuple, Union, Dict
from faker import Faker
fake = Faker()

# Blocked return prompt
BLOCKED_PROMPT: str = "REDACT_BLOCKED"

# Config (category => [sensitive level, redaction setting])
Config = Dict[str, Tuple[int, str]]

syntheticFn = {
    'Name': lambda: fake.language_name(),
    'Organization': lambda: fake.lexify(text='?????????'),
    'Email': lambda: fake.email(),
    'Location': lambda: fake.city(),
    'Phone Number': lambda: lambda:fake.msisdn(),
}

class Redactor:
    def redact(
        self, request: str, entity_map: List[EntityMapping], config: Config
    ) -> Union[str, Tuple[str, Dict[str, str]]]:
        """Redacts entities in a request based on the entity map.

        Args:
        request (str): The request to be redacted.
        entity_map (list): The entity map of detected entities.
        entity_config (Config): The entity config.

        Returns:
        tuple: The modified request(str) and the cached map of hash to entity(dict).
        """
        redact_map = {}
        modified_request = request

        for (entity_type, specific_entity) in entity_map:
            # Collect action
            action = None
            if entity_type in config:
                action = config[entity_type][1]

            # Block or redact
            if action == "block":
                return BLOCKED_PROMPT, {}
            elif action == "redact":
                entity_hash = syntheticFn[entity_type]() if entity_type in syntheticFn else f"{str(uuid.uuid4())}({entity_type})"
                redact_map[entity_hash] = specific_entity
                modified_request = modified_request.replace(
                    specific_entity, entity_hash
                )

        return modified_request, redact_map
